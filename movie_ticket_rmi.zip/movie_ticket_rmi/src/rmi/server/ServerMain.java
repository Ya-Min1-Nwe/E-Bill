package rmi.server;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class ServerMain {
    public static void main(String[] args) {
        try {
            // Start registry on 1099 (ok if already running)
            try { LocateRegistry.createRegistry(1099); } catch (Exception ignored) {}

            TicketServiceImpl service = new TicketServiceImpl();
            Naming.rebind("rmi://localhost:1099/TicketService", service);
            System.out.println("✅ RMI Server ready at rmi://localhost:1099/TicketService");
            System.out.println("DB connected");
        } catch (Exception e) {
            System.err.println("❌ Failed to start server");
            e.printStackTrace();
        }
    }
}