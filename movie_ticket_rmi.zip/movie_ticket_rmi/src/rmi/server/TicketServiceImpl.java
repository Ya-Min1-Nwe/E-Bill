package rmi.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import rmi.movieticket.TicketService;

public class TicketServiceImpl extends UnicastRemoteObject implements TicketService {

    private Connection conn;

    public TicketServiceImpl() throws RemoteException {
        try {
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/movie_ticket_rmi?useSSL=false&serverTimezone=UTC",
                "root", "yaminnwe"); // adjust user/pass
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String[] getMovies() throws RemoteException {
        List<String> list = new ArrayList<>();
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT name FROM movies")) {
            while (rs.next()) {
				list.add(rs.getString("name"));
			}
        } catch (SQLException e) { e.printStackTrace(); }
        return list.toArray(new String[0]);
    }

    @Override
    public boolean addMovie(String name, String posterPath, Date date, String time, String trailer) throws RemoteException {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO movies(name, poster_path, trailer_url, show_date, show_time) VALUES(?,?,?,?,?)");
            ps.setString(1, name);
            ps.setString(2, posterPath);
            ps.setString(3, trailer);
            ps.setDate(4, new java.sql.Date(date.getTime()));
            ps.setString(5, time);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateMovie(String oldName, String newName, String newPosterPath) throws RemoteException {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE movies SET name=?, poster_path=? WHERE name=?");
            ps.setString(1, newName);
            ps.setString(2, newPosterPath);
            ps.setString(3, oldName);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateMovie(String oldName, String newName, String newPosterPath, String newTrailerUrl) throws RemoteException {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE movies SET name=?, poster_path=?, trailer_url=? WHERE name=?");
            ps.setString(1, newName);
            ps.setString(2, newPosterPath);
            ps.setString(3, newTrailerUrl);
            ps.setString(4, oldName);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteMovie(String name) throws RemoteException {
        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM movies WHERE name=?");
            ps.setString(1, name);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public String getPoster(String movie) throws RemoteException {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT poster_path FROM movies WHERE name=?");
            ps.setString(1, movie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
				return rs.getString("poster_path");
			}
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public String getTrailer(String movie) throws RemoteException {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT trailer_url FROM movies WHERE name=?");
            ps.setString(1, movie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
				return rs.getString("trailer_url");
			}
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public String getShowTime(String movie) throws RemoteException {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT show_date, show_time FROM movies WHERE name=?");
            ps.setString(1, movie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
				return rs.getDate("show_date") + " | " + rs.getString("show_time");
			}
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public boolean bookTicket(String movie, String date, String time, String seat, String customer,String paymentMethod) throws RemoteException {
        try {
            // check if seat already booked
            PreparedStatement check = conn.prepareStatement(
                "SELECT * FROM bookings WHERE movie_name=? AND show_date=? AND show_time=? AND seat=?");
            check.setString(1, movie);
            check.setDate(2, java.sql.Date.valueOf(date));
            check.setString(3, time);
            check.setString(4, seat);
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
				return false;
			}

            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO bookings(movie_name, show_date, show_time, seat, customer_name, payment_method) VALUES(?,?,?,?,?,?)");
            ps.setString(1, movie);
            ps.setDate(2, java.sql.Date.valueOf(date));
            ps.setString(3, time);
            ps.setString(4, seat);
            ps.setString(5, customer);
            ps.setString(6, paymentMethod); // Payment method placeholder
            ps.executeUpdate();
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    @Override
    public String[] getAllBookings() throws RemoteException {
        List<String> list = new ArrayList<>();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM bookings ORDER BY booked_at DESC");
            while (rs.next()) {
            	String payment = rs.getString("payment_method");
                if (payment == null || payment.isEmpty()) {
                    payment = "Unknown";} // fallback
                String info = rs.getString("customer_name") + " booked " +
                        rs.getString("seat") + " for " +
                        rs.getString("movie_name") + " on " +
                        rs.getDate("show_date") + " | " +
                        rs.getString("show_time") + " (Paid: " +
                        rs.getString("payment_method") + ")";
                list.add(info);
            }}
         catch (SQLException e) { e.printStackTrace(); }
        return list.toArray(new String[0]);
    }

    @Override
    public String[] getBookedSeats(String movie, String date, String time) throws RemoteException {
        List<String> list = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT seat FROM bookings WHERE movie_name=? AND show_date=? AND show_time=?");
            ps.setString(1, movie);
            ps.setDate(2, java.sql.Date.valueOf(date));
            ps.setString(3, time);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
				list.add(rs.getString("seat"));
			}
        } catch (SQLException e) { e.printStackTrace(); }
        return list.toArray(new String[0]);
    }

    @Override
    public boolean cancelTicket(String movie, String date, String time, String seat, String customer) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM bookings WHERE movie_name=? AND show_date=? AND show_time=? AND seat=? AND customer_name=?");
            ps.setString(1, movie);
            ps.setDate(2, java.sql.Date.valueOf(date));
            ps.setString(3, time);
            ps.setString(4, seat);
            ps.setString(5, customer);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

	@Override
	public boolean addMovie(String name, String posterPath, Date date, String time) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addMovie(String name, String posterPath, java.sql.Date date, String time) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String[] getTimes() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean cancelTicket(String movie, String date, String time, String seat, String customer,
			String paymentMethod) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean bookSeat(String movie, String seatNumber) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}





	@Override
	public String getTrailerURL(String movie) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean bookTicket(String movie, String date, String time, String seat, String customer)
			throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}
}
