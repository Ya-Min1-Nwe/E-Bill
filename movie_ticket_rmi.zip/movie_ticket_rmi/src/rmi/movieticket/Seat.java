package rmi.movieticket;

public class Seat {
    private final int number;
    private String owner; // null if free

    public Seat(int number) { this.number = number; }
    public int getNumber() { return number; }
    public boolean isFree() { return owner == null; }
    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }
  public String getSeatNumber() {
    // TODO Auto-generated method stub
    return null;
  }
  public boolean isAvailable() {
    // TODO Auto-generated method stub
    return false;
  }
}