package rmi.movieticket;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;

public interface TicketService extends Remote {
    boolean cancelTicket(String movie, String date, String time, String seat, String customer) throws RemoteException;

    // တခြား methods တွေမှာလည်း RemoteException ထည့်ရမယ်
    String[] getMovies() throws RemoteException;
    String getPoster(String movie) throws RemoteException;
    String getTrailerURL(String movie) throws RemoteException;
    String getShowTime(String movie) throws RemoteException;
    boolean bookTicket(String movie, String date, String time, String seat, String customer) throws RemoteException;
    boolean bookTicket(String movie, String date, String time, String seat, String customer, String payment) throws RemoteException;
    String[] getBookedSeats(String movie, String date, String time) throws RemoteException;
    String[] getAllBookings() throws RemoteException;

	boolean addMovie(String name, String posterPath, Date date, String time, String trailer) throws RemoteException;

	boolean updateMovie(String oldName, String newName, String newPosterPath) throws RemoteException;

	boolean updateMovie(String oldName, String newName, String newPosterPath, String newTrailerUrl)
			throws RemoteException;

	boolean deleteMovie(String name) throws RemoteException;

	String getTrailer(String movie) throws RemoteException;

	boolean cancelTicket(String movie, String date, String time, String seat, String customer, String paymentMethod)
			throws RemoteException;

	boolean bookSeat(String movie, String seatNumber) throws RemoteException;

	String[] getTimes() throws RemoteException;

	boolean addMovie(String name, String posterPath, java.sql.Date date, String time) throws RemoteException;

	boolean addMovie(String name, String posterPath, Date date, String time) throws RemoteException;
}
