package rmi.movieticket;

import java.io.Serializable;

public class Movie implements Serializable {
    private String name;
    private String poster;
    private String trailerUrl; // NEW

    public Movie(String name, String poster, String trailerUrl) {
        this.name = name;
        this.poster = poster;
        this.trailerUrl = trailerUrl;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPoster() { return poster; }
    public void setPoster(String poster) { this.poster = poster; }

    public String getTrailerUrl() { return trailerUrl; }
    public void setTrailerUrl(String trailerUrl) { this.trailerUrl = trailerUrl; }
}