package rmi.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import com.toedter.calendar.JDateChooser;

public class AdminGUI extends JFrame {

    private final TicketClient client;

    private JComboBox<String> moviesCombo;
    private JTextField movieNameField, posterField, trailerField;
    private JTextField updateNameField, updatePosterField, updateTrailerField;
    private JTextArea bookingsArea;
    private JLabel posterPreview;
    private JSpinner dateSpinner;
    private JDateChooser dateChooser;
    private JComboBox<String> timeCombo;

    private JLabel salesLabel, topMovieLabel, totalMoviesLabel;
    private JButton trailerButton;

    // NEW: Tab components
    private JTabbedPane tabbedPane;
    private JPanel movieManagementPanel;
    private JPanel bookingsPanel;
    private JTextArea allBookingsArea;

    public AdminGUI() {
        client = new TicketClient();

        setTitle("🎬 CineMaster Admin Panel");
        setSize(1200, 850);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // ===== BEAUTIFUL WEBSITE-STYLE BANNER =====
        JPanel bannerPanel = new JPanel(new BorderLayout(20, 0));
        bannerPanel.setPreferredSize(new Dimension(1200, 150));
        bannerPanel.setBackground(new Color(41, 128, 185));
        bannerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        // Left side: Logo and Title
        JPanel leftBanner = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        leftBanner.setOpaque(false);

        JLabel logoLabel = new JLabel("🎬");
        logoLabel.setFont(new Font("Times New Roman", Font.BOLD, 36));
        logoLabel.setForeground(Color.WHITE);

        JLabel titleLabel = new JLabel("CINEMASTER ADMIN");
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);

        leftBanner.add(logoLabel);
        leftBanner.add(titleLabel);
        bannerPanel.add(leftBanner, BorderLayout.WEST);

        // Right side: Stats and trailer button
        JPanel rightBanner = new JPanel(new GridLayout(2, 3, 15, 8));
        rightBanner.setOpaque(false);

        // Stats labels with better styling
        salesLabel = createStatLabel("Tickets Sold: 0", "💰");
        totalMoviesLabel = createStatLabel("Movies: 0", "🎭");
        topMovieLabel = createStatLabel("Top Movie: N/A", "🏆");

        JLabel empty1 = new JLabel("");
        JLabel empty2 = new JLabel("");

        trailerButton = new JButton("▶️ Play Trailer");
        trailerButton.setBackground(new Color(52, 152, 219));
        trailerButton.setForeground(Color.BLACK);
        trailerButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        trailerButton.setBorder(BorderFactory.createRaisedBevelBorder());
        trailerButton.setFocusPainted(false);
        trailerButton.addActionListener(e -> playTrailer());

        rightBanner.add(salesLabel);
        rightBanner.add(totalMoviesLabel);
        rightBanner.add(topMovieLabel);
        rightBanner.add(empty1);
        rightBanner.add(empty2);
        rightBanner.add(trailerButton);

        bannerPanel.add(rightBanner, BorderLayout.EAST);

        // Center: Welcome message
        JLabel welcomeLabel = new JLabel("Welcome to Movie Management System", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
        welcomeLabel.setForeground(new Color(236, 240, 241));
        bannerPanel.add(welcomeLabel, BorderLayout.CENTER);

        add(bannerPanel, BorderLayout.NORTH);

        // ===== Tabbed Pane =====
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Times New Roman", Font.BOLD, 14));
        tabbedPane.setBackground(new Color(245, 245, 245));

        // Tab 1: Movie Management
        movieManagementPanel = createMovieManagementPanel();
        tabbedPane.addTab("🎬 Movie Management", movieManagementPanel);

        // Tab 2: Bookings List
        bookingsPanel = createBookingsPanel();
        tabbedPane.addTab("📋 Bookings List", bookingsPanel);

        add(tabbedPane, BorderLayout.CENTER);

        // Initial load
        refreshMovies();
        refreshBookingsList();
        refreshBanner();

        // Auto-refresh timer
        new Timer(5000, e -> {
            refreshBookings();
            refreshBookingsList();
            refreshBanner();
        }).start();
    }

    // ===== FIXED: Add the missing methods =====
    private void browseAdd(ActionEvent e) {
        posterField.setText(chooseImage());
    }

    private void browseUpdate(ActionEvent e) {
        updatePosterField.setText(chooseImage());
    }

    private String chooseImage() {
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			return fc.getSelectedFile().getAbsolutePath();
		}
        return null;
    }

    private void refreshMovies() {
        moviesCombo.removeAllItems();
        for (String m : client.getMovies()) {
			moviesCombo.addItem(m);
		}
        showPoster();
    }

    private void showPoster() {
        String m = (String) moviesCombo.getSelectedItem();
        if (m == null) {
            posterPreview.setText("No Poster");
            posterPreview.setIcon(null);
            return;
        }
        String path = client.getPoster(m);
        if (path != null && !path.isBlank()) {
            ImageIcon icon = new ImageIcon(path);
            posterPreview.setIcon(new ImageIcon(icon.getImage().getScaledInstance(350, 450, Image.SCALE_SMOOTH)));
            posterPreview.setText("");
        } else {
            posterPreview.setText("No Poster");
            posterPreview.setIcon(null);
        }
    }

    private void refreshBookings() {
        bookingsArea.setText(String.join("\n", client.getAllBookings()));
    }

    private void refreshBookingsList() {
        String[] bookings = client.getAllBookings();
        if (bookings.length == 0) {
            allBookingsArea.setText("No bookings yet.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Total Bookings: ").append(bookings.length).append("\n\n");

        for (String booking : bookings) {
            sb.append("• ").append(booking).append("\n");
        }

        allBookingsArea.setText(sb.toString());
    }

    // Helper method to create beautiful stat labels
    private JLabel createStatLabel(String text, String emoji) {
        JLabel label = new JLabel(emoji + " " + text, SwingConstants.CENTER);
        label.setFont(new Font("Times New Roman", Font.BOLD, 14));
        label.setForeground(Color.WHITE);
        label.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        label.setOpaque(true);
        label.setBackground(new Color(52, 73, 94, 200));
        label.setBorder(BorderFactory.createLineBorder(new Color(236, 240, 241), 1));
        return label;
    }

    // ===== Panel 1: Movie Management =====
    private JPanel createMovieManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(245, 245, 245));

        // Top panel (Movie selection)
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        topPanel.setBackground(new Color(236, 240, 241));
        topPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(52, 152, 219), 2),
                "Movie Selection", TitledBorder.CENTER, TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 12), new Color(44, 62, 80))
        );

        topPanel.add(new JLabel("Movies:"));
        moviesCombo = new JComboBox<>();
        moviesCombo.setFont(new Font("Times New Roman", Font.PLAIN, 12));
        moviesCombo.addActionListener(e -> showPoster());
        topPanel.add(moviesCombo);
        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.setBackground(new Color(46, 204, 113));
        refreshBtn.setForeground(Color.BLACK);
        refreshBtn.setFont(new Font("Times New Roman", Font.BOLD, 12));
        refreshBtn.addActionListener(e -> {
            refreshMovies();
            refreshBanner();
        });
        topPanel.add(refreshBtn);

        panel.add(topPanel, BorderLayout.NORTH);

        // Center: CRUD + Poster Preview
        JPanel center = new JPanel(new GridLayout(1, 2, 15, 10));
        center.setBackground(new Color(245, 245, 245));

        // CRUD panel with better styling
        JPanel crud = new JPanel(new GridLayout(3, 1, 10, 10));
        crud.setBorder(BorderFactory.createTitledBorder("Movie Controls"));
        crud.setBackground(new Color(245, 245, 245));

        // Add movie panel
        JPanel addPanel = createSectionPanel("Add New Movie", new Color(236, 240, 241));
        movieNameField = new JTextField(12);
        posterField = new JTextField(12);
        trailerField = new JTextField(15);

        addPanel.add(new JLabel("Movie:"));
        addPanel.add(movieNameField);
        addPanel.add(new JLabel("Poster:"));
        addPanel.add(posterField);
        JButton browseAdd = new JButton("Browse");
        browseAdd.setBackground(new Color(52, 152, 219));
        browseAdd.setForeground(Color.BLACK);
        browseAdd.addActionListener(this::browseAdd);
        addPanel.add(browseAdd);
        addPanel.add(new JLabel("Trailer URL:"));
        addPanel.add(trailerField);

        dateChooser = new JDateChooser();
        dateChooser.setDateFormatString("yyyy-MM-dd");
        dateChooser.setPreferredSize(new Dimension(120, 25));
        addPanel.add(new JLabel("Show Date:"));
        addPanel.add(dateChooser);

        timeCombo = new JComboBox<>(new String[]{
                "10:00 AM – 11:30 AM", "12:30 PM – 02:00 PM",
                "02:30 PM – 04:00 PM", "04:30 PM – 06:00 PM"
        });
        addPanel.add(new JLabel("Show Time:"));
        addPanel.add(timeCombo);

        JButton addBtn = new JButton("➕ Add Movie");
        addBtn.setBackground(new Color(46, 204, 113));
        addBtn.setForeground(Color.BLACK);
        addBtn.setFont(new Font("Times New Roman", Font.BOLD, 12));
        addBtn.addActionListener(e -> addMovie());
        addPanel.add(addBtn);

        crud.add(addPanel);

        // Update movie panel
        JPanel updPanel = createSectionPanel("Update Movie", new Color(254, 249, 231));
        updateNameField = new JTextField(12);
        updatePosterField = new JTextField(12);
        updateTrailerField = new JTextField(15);

        updPanel.add(new JLabel("Rename to:"));
        updPanel.add(updateNameField);
        updPanel.add(new JLabel("New Poster:"));
        updPanel.add(updatePosterField);
        JButton browseUpd = new JButton("Browse");
        browseUpd.setBackground(new Color(52, 152, 219));
        browseUpd.setForeground(Color.BLACK);
        browseUpd.addActionListener(this::browseUpdate);
        updPanel.add(browseUpd);
        updPanel.add(new JLabel("Trailer URL:"));
        updPanel.add(updateTrailerField);

        JButton updBtn = new JButton("✏️ Update Movie");
        updBtn.setBackground(new Color(241, 196, 15));
        updBtn.setForeground(Color.BLACK);
        updBtn.setFont(new Font("Times New Roman", Font.BOLD, 12));
        updBtn.addActionListener(e -> updateMovie());
        updPanel.add(updBtn);

        crud.add(updPanel);

        // Delete panel
        JPanel delPanel = createSectionPanel("Delete Movie", new Color(255, 235, 238));
        JButton delBtn = new JButton("🗑 Delete Selected");
        delBtn.setBackground(new Color(231, 76, 60));
        delBtn.setForeground(Color.BLACK);
        delBtn.setFont(new Font("Times New Roman", Font.BOLD, 12));
        delBtn.addActionListener(e -> deleteMovie());
        delPanel.add(delBtn);

        crud.add(delPanel);

        center.add(crud);

        // Poster preview panel
        JPanel preview = new JPanel(new BorderLayout());
        preview.setBorder(BorderFactory.createTitledBorder("Poster Preview"));
        posterPreview = new JLabel("No Poster", SwingConstants.CENTER);
        posterPreview.setPreferredSize(new Dimension(350, 450));
        posterPreview.setOpaque(true);
        posterPreview.setBackground(new Color(230, 230, 250));
        posterPreview.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 2));
        preview.add(posterPreview, BorderLayout.CENTER);

        center.add(preview);
        panel.add(center, BorderLayout.CENTER);

        // Bottom: Current Bookings
        bookingsArea = new JTextArea();
        bookingsArea.setEditable(false);
        bookingsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        bookingsArea.setBackground(Color.WHITE);
        JScrollPane sp = new JScrollPane(bookingsArea);
        sp.setBorder(BorderFactory.createTitledBorder("Recent Bookings"));
        sp.setPreferredSize(new Dimension(1100, 150));
        panel.add(sp, BorderLayout.SOUTH);

        return panel;
    }

    // Helper method for section panels
    private JPanel createSectionPanel(String title, Color bgColor) {
        JPanel panel = new JPanel(new FlowLayout());
        panel.setBackground(bgColor);
        panel.setBorder(BorderFactory.createTitledBorder(title));
        return panel;
    }

    // ===== Panel 2: Bookings List =====
    private JPanel createBookingsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(245, 245, 245));

        // Header
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headerPanel.setBackground(new Color(52, 152, 219));
        JLabel headerLabel = new JLabel("📋 ALL BOOKINGS", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        panel.add(headerPanel, BorderLayout.NORTH);

        // Bookings area
        allBookingsArea = new JTextArea();
        allBookingsArea.setEditable(false);
        allBookingsArea.setFont(new Font("Times New Roman", Font.PLAIN, 13));
        allBookingsArea.setBackground(Color.WHITE);
        allBookingsArea.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JScrollPane scrollPane = new JScrollPane(allBookingsArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Booking Details"));
        panel.add(scrollPane, BorderLayout.CENTER);

        // Refresh button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(245, 245, 245));
        JButton refreshBookingsBtn = new JButton("🔄 Refresh Bookings");
        refreshBookingsBtn.setBackground(new Color(46, 204, 113));
        refreshBookingsBtn.setForeground(Color.BLACK);
        refreshBookingsBtn.setFont(new Font("Times New Roman", Font.BOLD, 14));
        refreshBookingsBtn.addActionListener(e -> refreshBookingsList());
        buttonPanel.add(refreshBookingsBtn);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    // ===== CRUD Methods =====
    private void addMovie() {
        String name = movieNameField.getText().trim();
        String poster = posterField.getText().trim();
        String trailer = trailerField.getText().trim();
        Date date = dateChooser.getDate();
        String time = (String) timeCombo.getSelectedItem();

        if (name.isEmpty() || time == null) {
            JOptionPane.showMessageDialog(this, "Please fill all fields");
            return;
        }

        if (client.addMovie(name, poster, date, time, trailer)) {
            movieNameField.setText("");
            posterField.setText("");
            trailerField.setText("");
            refreshMovies();
            JOptionPane.showMessageDialog(this, "✅ Movie added successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "❌ Failed to add movie");
        }
    }

    private void updateMovie() {
        String oldName = (String) moviesCombo.getSelectedItem();
        if (oldName == null) {
            JOptionPane.showMessageDialog(this, "⚠️ Please select a movie to update.");
            return;
        }

        String newName = updateNameField.getText().trim();
        String newPosterPath = updatePosterField.getText().trim();
        String newTrailerUrl = updateTrailerField.getText().trim();

        try {
            boolean success = client.updateMovie(oldName, newName, newPosterPath, newTrailerUrl);
            if (success) {
                JOptionPane.showMessageDialog(this, "✅ Movie updated successfully!");
                refreshMovies();
                updateNameField.setText("");
                updatePosterField.setText("");
                updateTrailerField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "❌ Update failed. Please check inputs.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "⚠️ Error: " + e.getMessage());
        }
    }

    private void deleteMovie() {
        String m = (String) moviesCombo.getSelectedItem();
        if (m == null) {
            JOptionPane.showMessageDialog(this, "Please select a movie");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete '" + m + "'?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (client.deleteMovie(m)) {
                refreshMovies();
                JOptionPane.showMessageDialog(this, "🗑 Movie deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "❌ Failed to delete movie");
            }
        }
    }

        		    private void playTrailer() {
        		        String movie = (String) moviesCombo.getSelectedItem();
        		        if (movie == null) {
        		            JOptionPane.showMessageDialog(this, "Please select a movie first");
        		            return;
        		        }
        		        try {
        		            String url = client.getTrailer(movie);
        		            if (url != null && !url.isBlank()) {
        		                java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
        		            } else {
        		                JOptionPane.showMessageDialog(this, "No trailer available for this movie");
        		            }
        		        } catch (Exception ex) {
        		            JOptionPane.showMessageDialog(this, "Failed to open trailer: " + ex.getMessage());
        		        }
        		    }


        		    private void refreshBanner() {
        		        salesLabel.setText("💰 Tickets Sold: " + client.getAllBookings().length);
        		        totalMoviesLabel.setText("🎭 Movies: " + client.getMovies().length);

        		        String top = client.getTopMovie();
        		        topMovieLabel.setText("🏆 Top Movie: " + top);

        		        // Enable/disable trailer button
        		        String selectedMovie = (String) moviesCombo.getSelectedItem();
        		        trailerButton.setEnabled(selectedMovie != null && client.getTrailer(selectedMovie) != null);
        		    }


        		    public static void main(String[] args) {
        		        SwingUtilities.invokeLater(() -> {
        		            try {
        		                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        		            } catch (Exception e) {
        		                e.printStackTrace();
        		            }
        		            new AdminGUI().setVisible(true);
        		        });
        		    }
        		}