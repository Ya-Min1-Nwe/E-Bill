package rmi.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

public class UserGUI extends JFrame {

    private JTextField nameField;
    private final Map<String, String> movies = new LinkedHashMap<>();
    private final Map<String, Integer> movieSeats = new HashMap<>();
    private final Map<String, List<JButton>> movieSeatButtons = new HashMap<>();
    private final Map<String, Set<String>> bookedSeats = new HashMap<>(); // 🎟 Already booked seats

    public UserGUI() {
        setTitle("Movie Ticket Booking - User View");
        setSize(1200, 700);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 🎬 Movies with poster images
        movies.put("Avatar", "images/Avatar.jpg");
        movies.put("Titanic", "images/Titanic.jpg");
        movies.put("Inception", "images/Inception.jpg");
        movies.put("The Matrix", "images/TheMatrix.jpg");
        movies.put("Interstellar", "images/Interstellar.jpg");
        movies.put("Avengers", "images/Avengers.jpg");
        movies.put("Iron Man", "images/IronMan.jpg");
        movies.put("Frozen", "images/Frozen.jpg");

        // 🎟 Seat counts
        movieSeats.put("Avatar", 10);
        movieSeats.put("Titanic", 10);
        movieSeats.put("Inception", 8);
        movieSeats.put("The Matrix", 10);
        movieSeats.put("Interstellar", 10);
        movieSeats.put("Avengers", 10);
        movieSeats.put("Iron Man", 10);
        movieSeats.put("Frozen", 12);

        setLayout(new BorderLayout());

        // Top panel: user name
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Your Name:"));
        nameField = new JTextField(20);
        topPanel.add(nameField);
        add(topPanel, BorderLayout.NORTH);


        // Center panel: all movies
        JPanel centerPanel = new JPanel(new GridLayout(0, 2, 20, 20));

        for (String movieName : movies.keySet()) {
            bookedSeats.put(movieName, new HashSet<>()); // init booked seats for each movie
            JPanel moviePanel = createMoviePanel(movieName, movies.get(movieName), movieSeats.get(movieName));
            centerPanel.add(moviePanel);
        }

        JScrollPane scrollPane = new JScrollPane(centerPanel);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createMoviePanel(String movieName, String imagePath, int seatCount) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));

        // Poster Image
        JLabel imgLabel;
        try {
            ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource(imagePath));
            if (icon.getIconWidth() == -1) {
				throw new Exception("Image not found");
			}
            Image img = icon.getImage().getScaledInstance(200, 250, Image.SCALE_SMOOTH);
            imgLabel = new JLabel(new ImageIcon(img));
        } catch (Exception e) {
            imgLabel = new JLabel("No Image", SwingConstants.CENTER);
        }
        panel.add(imgLabel, BorderLayout.NORTH);

        // Seats Panel (buttons)
        JPanel seatPanel = new JPanel(new GridLayout(0, 5, 5, 5));
        List<JButton> seatButtons = new ArrayList<>();

        for (int i = 1; i <= seatCount; i++) {
            String seatNo = "A" + i;
            JButton seatBtn = new JButton(seatNo);

            // check if already booked
            if (bookedSeats.get(movieName).contains(seatNo)) {
                seatBtn.setBackground(Color.RED);
                seatBtn.setEnabled(false); // disable if booked
            } else {
                seatBtn.setBackground(Color.GREEN);
                seatBtn.addActionListener(ae -> bookSeat(movieName, seatBtn));
            }

            seatButtons.add(seatBtn);
            seatPanel.add(seatBtn);
        }

        movieSeatButtons.put(movieName, seatButtons);
        panel.add(seatPanel, BorderLayout.CENTER);

        // Movie name label
        JLabel nameLbl = new JLabel(movieName, SwingConstants.CENTER);
        nameLbl.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(nameLbl, BorderLayout.SOUTH);

        return panel;
    }

    // ✅ Book seat permanently
    private void bookSeat(String movie, JButton seatBtn) {
        String user = nameField.getText().trim();
        if (user.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your name first.");
            return;
        }

        String seatNo = seatBtn.getText();

        if (!bookedSeats.get(movie).contains(seatNo)) {
            bookedSeats.get(movie).add(seatNo);
            seatBtn.setBackground(Color.RED);
            seatBtn.setEnabled(false); // disable after booking
            JOptionPane.showMessageDialog(this, user + " booked seat " + seatNo + " for " + movie);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UserGUI().setVisible(true));
    }

	public String[] getMovies() {
		// TODO Auto-generated method stub
		return null;
	}

	public Set<String> getBookedSeats(String movie) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<JButton> getSeatButtons(String movie) {
		// TODO Auto-generated method stub
		return null;
	}
	// Return movie names


	// Return list of seat buttons for a movie


}
