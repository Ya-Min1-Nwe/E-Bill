package rmi.client;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TicketClient {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/movie_ticket_rmi?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root"; // MySQL username
    private static final String PASSWORD = "yaminnwe"; // MySQL password

    private Connection conn;

    public TicketClient() {
        try {
            conn = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ===== Movies =====
    public String[] getMovies() {
        List<String> list = new ArrayList<>();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT name FROM movies");
            while (rs.next()) {
                list.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list.toArray(new String[0]);
    }

    public String getPoster(String movie) {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT poster_path FROM movies WHERE name=?");
            ps.setString(1, movie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
				return rs.getString("poster_path");
			}
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getTrailerURL(String movie) {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT trailer_url FROM movies WHERE name=?");
            ps.setString(1, movie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
				return rs.getString("trailer_url");
			}
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getShowTime(String movie) {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT show_date, show_time FROM movies WHERE name=?");
            ps.setString(1, movie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDate("show_date") + " | " + rs.getString("show_time");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }

    // ===== Bookings =====


    public boolean bookTicket(String movie, String date, String time, String seat, String customer,String paymentMethod) {
        try {
            // check if seat already booked
            PreparedStatement check = conn.prepareStatement(
                    "SELECT * FROM bookings WHERE movie_name=? AND show_date=? AND show_time=? AND seat=?");
            check.setString(1, movie);
            check.setDate(2, Date.valueOf(date));
            check.setString(3, time);
            check.setString(4, seat);
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
				return false; // seat already booked
			}

            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO bookings(movie_name, show_date, show_time, seat, customer_name, payment_method) VALUES(?,?,?,?,?,?)");
            ps.setString(1, movie);
            ps.setDate(2, Date.valueOf(date));
            ps.setString(3, time);
            ps.setString(4, seat);
            ps.setString(5, customer);
            ps.setString(6, paymentMethod);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String[] getBookedSeats(String movie, String date, String time) {
        List<String> list = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT seat FROM bookings WHERE movie_name=? AND show_date=? AND show_time=?");
            ps.setString(1, movie);
            ps.setDate(2, Date.valueOf(date));
            ps.setString(3, time);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
				list.add(rs.getString("seat"));
			}
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list.toArray(new String[0]);
    }

    public String[] getAllBookings() {
        List<String> list = new ArrayList<>();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM bookings ORDER BY booked_at DESC");
            while (rs.next()) {
                String info = rs.getString("customer_name") + " booked " +
                        rs.getString("seat") + " for " +
                        rs.getString("movie_name") + " on " +
                        rs.getDate("show_date") + " | " +
                        rs.getString("show_time") + " (Paid: " +
                        rs.getString("payment_method") + ")";
                list.add(info);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list.toArray(new String[0]);
    }
 // ===== Movies Management =====
    public boolean addMovie(String name, String poster, java.util.Date showDate, String showTime, String trailer) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO movies(name, poster_path, trailer_url, show_date, show_time) VALUES(?,?,?,?,?)"
            );
            ps.setString(1, name);
            ps.setString(2, poster);
            ps.setString(3, trailer);
            ps.setDate(4, new java.sql.Date(showDate.getTime())); // util.Date -> sql.Date
            ps.setString(5, showTime);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateMovie(String oldName, String newName, String newPoster, String newTrailer) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE movies SET name = ?, poster_path = ?, trailer_url = ? WHERE name = ?"
            );
            ps.setString(1, newName.isEmpty() ? oldName : newName); // old default
            ps.setString(2, newPoster);
            ps.setString(3, newTrailer);
            ps.setString(4, oldName);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
 // in TicketClient.java
    public String getTrailer(String movie) {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT trailer_url FROM movies WHERE name=?");
            ps.setString(1, movie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
				return rs.getString("trailer_url");
			}
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }



    public boolean deleteMovie(String name) {
        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM movies WHERE name=?");
            ps.setString(1, name);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }}



     // TicketClient.java
        public String getTopMovie() {
            try {
                PreparedStatement ps = conn.prepareStatement(
                    "SELECT movie_name, COUNT(*) AS cnt FROM bookings GROUP BY movie_name ORDER BY cnt DESC LIMIT 1"
                );
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return rs.getString("movie_name");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return "N/A";
        }

    }






