package rmi.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

public class TicketBookingGUI extends JFrame {

    private final TicketClient client;

    private JPanel moviesPanel;
    private JTextField nameField;
    private JLabel posterLabel;
    private JPanel seatPanel;
    private JButton[][] seatButtons;
    private final Set<String> selectedSeats = new HashSet<>();

    private String selectedMovie;
    private String selectedShowTime;

    private JButton trailerButton; // Play trailer button
    private Map<String, String> trailerMap = new HashMap<>(); // movie -> trailer URL

    private static final int ROWS = 5, COLS = 5; // 5x5 seat grid

    public TicketBookingGUI() {
        client = new TicketClient();

        setTitle("🎟 Ticket Booking System");
        setSize(950, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        getContentPane().setBackground(new Color(176, 224, 230));

        // ===== Top: Customer name =====
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        topPanel.setBackground(new Color(135, 206, 250));
        topPanel.setBorder(BorderFactory.createTitledBorder("Customer Info"));
        topPanel.add(new JLabel("Your Name:"));
        nameField = new JTextField(15);
        topPanel.add(nameField);
        add(topPanel, BorderLayout.NORTH);

        // ===== Center: Movies + Right Panel =====
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(new Color(245, 245, 245));

        // Movies grid
        moviesPanel = new JPanel(new GridLayout(0, 3, 10, 10));
        JScrollPane scrollPane = new JScrollPane(moviesPanel);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Available Movies"));
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        // Right panel: poster + seats + book button + trailer
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));
        rightPanel.setPreferredSize(new Dimension(400, 520));
        rightPanel.setBackground(new Color(245, 245, 245));
        rightPanel.setBorder(BorderFactory.createTitledBorder("Book Your Seats"));

        posterLabel = new JLabel("Select a movie", SwingConstants.CENTER);
        posterLabel.setPreferredSize(new Dimension(380, 250));
        posterLabel.setOpaque(true);
        posterLabel.setBackground(new Color(230, 230, 250));
        posterLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        posterLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                openPosterTrailer();
            }
        });
        rightPanel.add(posterLabel, BorderLayout.NORTH);

        // Seat grid
        seatPanel = new JPanel(new GridLayout(ROWS, COLS, 5, 5));
        seatButtons = new JButton[ROWS][COLS];
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                String seatId = "" + (char) ('A' + r) + (c + 1);
                JButton b = new JButton(seatId);
                b.setBackground(Color.GREEN);
                b.setOpaque(true);
                b.addActionListener(e -> toggleSeat(b));
                seatButtons[r][c] = b;
                seatPanel.add(b);
            }
        }
        rightPanel.add(seatPanel, BorderLayout.CENTER);

        // Trailer + Book button panel
        JPanel bottomPanel = new JPanel(new GridLayout(2, 1, 5, 5));

        trailerButton = new JButton("▶️ Play Trailer");
        trailerButton.setBackground(Color.BLACK);
        trailerButton.setForeground(Color.WHITE);
        trailerButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
        trailerButton.setEnabled(false); // initially disabled
        trailerButton.addActionListener(e -> playTrailer());
        bottomPanel.add(trailerButton);

        JButton bookBtn = new JButton("✅ Book Selected Seats");
        bookBtn.setBackground(new Color(135, 206, 250));
        bookBtn.setForeground(Color.BLACK);
        bookBtn.setFont(new Font("Times New Roman", Font.BOLD, 14));
        bookBtn.addActionListener(this::bookSelectedSeats);
        bottomPanel.add(bookBtn);

        rightPanel.add(bottomPanel, BorderLayout.SOUTH);

        centerPanel.add(rightPanel, BorderLayout.EAST);

        add(centerPanel, BorderLayout.CENTER);

        // ===== Load movies =====
        loadMovies();
    }

    private void loadMovies() {
        moviesPanel.removeAll();
        String[] movies = client.getMovies();

        for (String movie : movies) {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createTitledBorder(movie));
            panel.setBackground(new Color(224, 255, 255));
            panel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            // Poster
            String posterPath = client.getPoster(movie);
            ImageIcon icon = posterPath != null && !posterPath.isBlank()
                    ? new ImageIcon(posterPath)
                    : null;
            JLabel picLabel = new JLabel();
            if (icon != null) {
				picLabel.setIcon(new ImageIcon(icon.getImage().getScaledInstance(380, 250, Image.SCALE_SMOOTH)));
			}
            panel.add(picLabel, BorderLayout.CENTER);

            // Show time
            String showTime = client.getShowTime(movie);
            JLabel timeLabel = new JLabel(showTime, SwingConstants.CENTER);
            timeLabel.setOpaque(true);
            timeLabel.setBackground(new Color(30, 144, 255));
            timeLabel.setForeground(Color.WHITE);
            timeLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
            timeLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            panel.add(timeLabel, BorderLayout.SOUTH);

            panel.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    selectedMovie = movie;
                    selectedShowTime = showTime;
                    posterLabel.setIcon(icon != null ?
                            new ImageIcon(icon.getImage().getScaledInstance(380, 250, Image.SCALE_SMOOTH)) : null);

                    // Load trailer URL for this movie
                    String trailerUrl = client.getTrailerURL(movie); // implement in TicketClient
                    if (trailerUrl != null && !trailerUrl.isBlank()) {
                        trailerMap.put(movie, trailerUrl);
                        trailerButton.setEnabled(true);
                    } else {
                        trailerButton.setEnabled(false);
                    }

                    refreshSeatButtons();
                }
            });

            moviesPanel.add(panel);
        }

        moviesPanel.revalidate();
        moviesPanel.repaint();
    }

    private void refreshSeatButtons() {
        selectedSeats.clear();
        if (selectedMovie == null || selectedShowTime == null) {
			return;
		}

        String[] parts = selectedShowTime.split("\\|");
        String date = parts[0].trim();
        String time = parts[1].trim();
        String[] bookedSeats = client.getBookedSeats(selectedMovie, date, time);

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                JButton b = seatButtons[r][c];
                if (Arrays.asList(bookedSeats).contains(b.getText())) {
                    b.setBackground(Color.RED);
                } else {
                    b.setBackground(Color.GREEN);
                }
            }
        }
    }

    private void toggleSeat(JButton btn) {
        if (Color.RED.equals(btn.getBackground())) {
			return;
		}

        if (Color.GREEN.equals(btn.getBackground())) {
            btn.setBackground(Color.YELLOW);
            selectedSeats.add(btn.getText());
        } else if (Color.YELLOW.equals(btn.getBackground())) {
            btn.setBackground(Color.GREEN);
            selectedSeats.remove(btn.getText());
        }
    }

    // ===== UPDATED: Book seats with payment method selection =====
    private void bookSelectedSeats(ActionEvent e) {
        if (selectedMovie == null || selectedShowTime == null) {
            JOptionPane.showMessageDialog(this, "Select a movie first!");
            return;
        }

        String customer = nameField.getText().trim();
        if (customer.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter your name!");
            return;
        }

        // ===== Payment selection =====
        Object[] paymentOptions = {"💳 KBZ", "📲 Wave"};
        Object payment = JOptionPane.showInputDialog(
                this,
                "Choose your payment method:",
                "Payment Method",
                JOptionPane.PLAIN_MESSAGE,
                null,
                paymentOptions,
                paymentOptions[0]
        );

        if (payment == null) {
            JOptionPane.showMessageDialog(this, "Booking cancelled: Payment not selected.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "You chose " + payment + ". Confirm payment to book?",
                "Payment Confirmation",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Booking cancelled: Payment not made.");
            return;
        }

        // ===== Proceed to book seats =====
        String[] parts = selectedShowTime.split("\\|");
        String date = parts[0].trim();
        String time = parts[1].trim();

        boolean allOk = true;
        List<String> booked = new ArrayList<>();
        for (String seat : new ArrayList<>(selectedSeats)) {
            boolean ok = client.bookTicket(selectedMovie, date, time, seat, customer,payment.toString());
            if (ok) {
				booked.add(seat);
			}
            allOk &= ok;
        }

        if (!booked.isEmpty()) {
            JOptionPane.showMessageDialog(this, "✅ Booked seats: " + booked + "\nPaid via: " + payment);
        }
        if (!allOk) {
            JOptionPane.showMessageDialog(this, "❌ Some seats could not be booked.");
        }

        refreshSeatButtons();
    }

    private void playTrailer() {
        openPosterTrailer();
    }

    private void openPosterTrailer() {
        if (selectedMovie == null) {
			return;
		}
        String url = trailerMap.get(selectedMovie);
        if (url == null || url.isBlank()) {
            JOptionPane.showMessageDialog(this, "No trailer available.");
            return;
        }
        try {
            Desktop.getDesktop().browse(new java.net.URI(url));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TicketBookingGUI().setVisible(true));
    }
}
