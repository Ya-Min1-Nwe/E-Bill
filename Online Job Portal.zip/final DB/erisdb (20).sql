-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Sep 11, 2025 at 03:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erisdb`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ArchiveOldJobs` ()   BEGIN
    INSERT INTO tbl_job_archive (JOBID, OCCUPATIONTITLE, COMPANYNAME)
    SELECT j.JOBID, j.OCCUPATIONTITLE, c.COMPANYNAME
    FROM tbljob j
    INNER JOIN tblcompany c ON j.COMPANYID = c.COMPANYID
    WHERE j.DATEPOSTED < DATE_SUB(NOW(), INTERVAL 6 MONTH);
    
    SELECT CONCAT('Archived ', ROW_COUNT(), ' jobs') as Result;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `BackupApplicantsData` ()   BEGIN
    INSERT INTO tbl_backup_log (table_name, record_count, backed_up_by)
    VALUES ('tblapplicants', (SELECT COUNT(*) FROM tblapplicants), CURRENT_USER());
    
    -- In real system, you would export data here
    SELECT 'Backup completed successfully' as Result;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetApplicantsByCategory` (IN `category_name` VARCHAR(250))   BEGIN
    SELECT 
        j.CATEGORY,
        j.OCCUPATIONTITLE,
        c.COMPANYNAME,
        COUNT(r.APPLICANTID) AS ApplicantCount
    FROM tbljob j
    INNER JOIN tblcompany c ON j.COMPANYID = c.COMPANYID
    LEFT JOIN tbljobregistration r ON j.JOBID = r.JOBID
    WHERE j.CATEGORY = category_name
    GROUP BY j.JOBID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetCompanyStats` ()   BEGIN
    SELECT 
        c.COMPANYNAME,
        COUNT(j.JOBID) AS TotalJobs,
        COUNT(r.APPLICANTID) AS TotalApplications
    FROM tblcompany c
    LEFT JOIN tbljob j ON c.COMPANYID = j.COMPANYID
    LEFT JOIN tbljobregistration r ON j.JOBID = r.JOBID
    GROUP BY c.COMPANYID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TestProcedure` ()   SELECT 'Hello Myanmar!' AS Message$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblapplicants`
--

CREATE TABLE `tblapplicants` (
  `APPLICANTID` int(11) NOT NULL,
  `FNAME` varchar(90) NOT NULL,
  `LNAME` varchar(90) NOT NULL,
  `MNAME` varchar(90) NOT NULL,
  `ADDRESS` varchar(255) NOT NULL,
  `SEX` varchar(11) NOT NULL,
  `CIVILSTATUS` varchar(30) NOT NULL,
  `BIRTHDATE` date NOT NULL,
  `BIRTHPLACE` varchar(255) NOT NULL,
  `AGE` int(2) NOT NULL,
  `USERNAME` varchar(90) NOT NULL,
  `PASS` varchar(90) NOT NULL,
  `EMAILADDRESS` varchar(90) NOT NULL,
  `CONTACTNO` varchar(90) NOT NULL,
  `DEGREE` text NOT NULL,
  `APPLICANTPHOTO` varchar(255) NOT NULL,
  `NATIONALID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblapplicants`
--

INSERT INTO `tblapplicants` (`APPLICANTID`, `FNAME`, `LNAME`, `MNAME`, `ADDRESS`, `SEX`, `CIVILSTATUS`, `BIRTHDATE`, `BIRTHPLACE`, `AGE`, `USERNAME`, `PASS`, `EMAILADDRESS`, `CONTACTNO`, `DEGREE`, `APPLICANTPHOTO`, `NATIONALID`) VALUES
(2018013, 'Kim', 'Domingo', 'Enoe', 'Kab City', 'Female', 'none', '1991-01-01', 'Kab Citys', 27, 'kim', 'a6312121e15caec74845b7ba5af23330d52d4ac0', 'kim@y.com', '5415456', 'BSAC', 'photos/RobloxScreenShot20180406_203758793.png', ''),
(2018014, 'Jake', 'Zyrus', 'Ilmba', 'Kab City', 'Female', 'none', '1993-01-16', 'Kab City', 25, 'jake', 'c8d99c2f7cd5f432c163abcd422672b9f77550bb', 'jake@y.com', '14655623123123', 'BSIT', '', ''),
(2018015, 'Janry', 'Tan', 'Lim', 'brgy 1 Kab City', 'Female', 'Single', '1992-01-30', 'Kab City', 26, 'janry', '1dd4efc811372cd1efe855981a8863d10ddde1ca', 'jan@gmail.com', '0234234', 'BSIT', '', ''),
(2025016, 'Mee', 'Aye', 'Mee', 'Taunggyi', 'Female', 'Single', '2000-08-17', 'Taunggyi', 25, 'meeaye', '55505fb1f7748313f4fd6dd7e24803359d196bb0', 'meeaye@gmail.com', '09897654321', 'normal', '', ''),
(2025017, 'zin', 'moe', 'zin', 'AungBan', 'Female', 'Single', '1998-08-17', 'AungBan', 27, 'zinmoe', '9aff00729bb51f0fca5afc1d3a23125b83d54dd2', 'moe@gamil.com', '09886543211', '-', '', ''),
(2025018, 'ma', 'aye', 'ma', 'Kalaw', 'Female', 'Single', '2003-10-01', 'Kalaw', 21, 'maaye', '816655805ed98413f9451221d50850c3a10205b7', 'ma@gmail.com', '09898765454', '-', '', ''),
(2025019, 'Kyaw', 'San', 'Kyaw', 'Heho', 'Female', 'Single', '2000-10-02', 'Heho', 24, 'kyaw', '8222c91d98a4c5c7c5cb748f8b9769779ba4e5a6', 'kyaw@gamil.com', '09898765432', 'graduate', '', ''),
(2025020, 'Mg', 'Oo', 'Mg', 'Naypyidaw', '', 'Married', '2000-10-03', 'Naypyidaw', 24, 'mg', '191be3715bae070c2198402843567588417de697', 'mg@gmail.com', '09898767654', 'Bachelor in IT', '', ''),
(2025021, 'Khin', 'Aye', 'Khin', 'Yangon', '', 'Single', '2000-06-14', 'Yangon', 25, 'khinaye', '8370ab176c42d1b8070b85db8f7a4b55497711c5', 'khinaye@gmail.com', '09897676543', 'High school diploma', 'photos/first1.jpg', ''),
(2025022, 'Nadi', 'Oo', 'Lay', 'Kalaw', '', 'Single', '2000-01-01', 'Shan State', 25, 'nadi', '0fe8eb6be8ae16c332b4f7a418b4cd25ce4db93b', 'nadi@gmail.com', '09898767654', '-', '', ''),
(2025024, 'Nar', 'Shi', 'Hti', 'Mong Ping', '', 'Single', '2003-02-14', 'Shan State', 22, 'narhti', '526f5bd08d2cb0532106aa663d94e528ff4ca32f', 'shi123@gmail.com', '09454323211', 'Bachelor\\\'s degree', 'photos/first1.jpg', ''),
(2025025, 'Mg', 'Soe', 'Aung', 'Inlay', '', 'Married', '2001-01-12', 'Shan State', 24, 'aungsoe', '496971d1a844e826308e463606910445dcaf0bdc', 'soe123@gmail.com', '09897876543', 'Diploma', 'photos/photo_1_2025-09-11_06-46-52.jpg', '');

--
-- Triggers `tblapplicants`
--
DELIMITER $$
CREATE TRIGGER `after_applicant_delete` AFTER DELETE ON `tblapplicants` FOR EACH ROW BEGIN
    INSERT INTO tbl_audit_log (TABLE_NAME, ACTION_TYPE, RECORD_ID, OLD_DATA, USER_NAME)
    VALUES ('tblapplicants', 'DELETE', OLD.APPLICANTID,
            CONCAT('Deleted: ', OLD.FNAME, ' ', OLD.LNAME, ', Email: ', OLD.EMAILADDRESS), 
            CURRENT_USER());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_applicant_insert` AFTER INSERT ON `tblapplicants` FOR EACH ROW BEGIN
    INSERT INTO tbl_audit_log (TABLE_NAME, ACTION_TYPE, RECORD_ID, NEW_DATA, USER_NAME)
    VALUES ('tblapplicants', 'INSERT', NEW.APPLICANTID, 
            CONCAT('Name: ', NEW.FNAME, ' ', NEW.LNAME, ', Email: ', NEW.EMAILADDRESS), 
            CURRENT_USER());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_applicant_update` AFTER UPDATE ON `tblapplicants` FOR EACH ROW BEGIN
    INSERT INTO tbl_audit_log (TABLE_NAME, ACTION_TYPE, RECORD_ID, OLD_DATA, NEW_DATA, USER_NAME)
    VALUES ('tblapplicants', 'UPDATE', NEW.APPLICANTID,
            CONCAT('Old: ', OLD.FNAME, ' ', OLD.LNAME, ', Email: ', OLD.EMAILADDRESS),
            CONCAT('New: ', NEW.FNAME, ' ', NEW.LNAME, ', Email: ', NEW.EMAILADDRESS), 
            CURRENT_USER());
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `validate_applicant_email` BEFORE INSERT ON `tblapplicants` FOR EACH ROW BEGIN
    IF NEW.EMAILADDRESS NOT LIKE '%@%.%' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid email address format';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblattachmentfile`
--

CREATE TABLE `tblattachmentfile` (
  `ID` int(11) NOT NULL,
  `FILEID` varchar(30) DEFAULT NULL,
  `JOBID` int(11) NOT NULL,
  `FILE_NAME` varchar(90) NOT NULL,
  `FILE_LOCATION` varchar(255) NOT NULL,
  `USERATTACHMENTID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblattachmentfile`
--

INSERT INTO `tblattachmentfile` (`ID`, `FILEID`, `JOBID`, `FILE_NAME`, `FILE_LOCATION`, `USERATTACHMENTID`) VALUES
(2, '2147483647', 2, 'Resume', 'photos/27052018124027PLATENO FE95483.docx', 2018013),
(3, '20256912529', 2, 'Resume', 'photos/08092025055727first1.jpg', 2025016),
(4, '20256912531', 0, 'Resume', 'photos/09092025121410cv1.jpg', 2025017),
(5, '20256912532', 1, 'Resume', 'photos/09092025123233cv2.jpg', 2025018),
(6, '20256912533', 3, 'Resume', 'photos/09092025123903cv3.jpg', 2025019),
(7, '20256912535', 5, 'Resume', 'photos/09092025015200cv6.jpg', 2025020),
(8, '20256912536', 3, 'Resume', 'photos/09092025015407cv6.jpg', 2025020),
(9, '20256912537', 12, 'Resume', 'photos/09092025122917cv4.jpg', 2025021),
(10, '20256912538', 21, 'Resume', 'photos/09092025123148cv4.jpg', 2025021),
(11, '20256912539', 21, 'Resume', 'photos/11092025123940cv2.jpg', 2025023),
(12, '20256912540', 21, 'Resume', 'photos/11092025124121cv2.jpg', 2025024),
(13, '20256912541', 30, 'Resume', 'photos/11092025124420happy.png', 2025024),
(14, '20256912542', 31, 'Resume', 'photos/11092025023807photo_4_2025-09-11_06-44-40.jpg', 2025025),
(15, '20256912543', 30, 'Resume', 'photos/11092025024023photo_4_2025-09-11_06-44-40.jpg', 2025025);

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumbers`
--

CREATE TABLE `tblautonumbers` (
  `AUTOID` int(11) NOT NULL,
  `AUTOSTART` varchar(30) NOT NULL,
  `AUTOEND` int(11) NOT NULL,
  `AUTOINC` int(11) NOT NULL,
  `AUTOKEY` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblautonumbers`
--

INSERT INTO `tblautonumbers` (`AUTOID`, `AUTOSTART`, `AUTOEND`, `AUTOINC`, `AUTOKEY`) VALUES
(1, '02983', 10, 1, 'userid'),
(2, '000', 84, 1, 'employeeid'),
(3, '0', 26, 1, 'APPLICANT'),
(4, '69125', 44, 1, 'FILEID');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CATEGORYID` int(11) NOT NULL,
  `CATEGORY` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`CATEGORYID`, `CATEGORY`) VALUES
(10, 'Technology'),
(11, 'Managerial'),
(12, 'Engineering'),
(13, 'IT'),
(14, 'Construction &Engineering'),
(15, 'HR'),
(23, 'Sales'),
(25, 'Finance'),
(28, 'Shipping'),
(29, 'Banking & Finance'),
(30, 'Telecommunications'),
(32, 'Hospitality & Tourism'),
(33, 'Import/Export Trade'),
(34, 'NGO & Social Services'),
(35, 'Education & Teaching'),
(36, 'Agriculture & Farming'),
(38, 'Government Jobs'),
(39, 'Manufacturing & Production'),
(40, 'Production Operator'),
(41, 'cleaning'),
(43, 'Driver');

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--

CREATE TABLE `tblcompany` (
  `COMPANYID` int(11) NOT NULL,
  `COMPANYNAME` varchar(90) NOT NULL,
  `COMPANYADDRESS` varchar(90) NOT NULL,
  `COMPANYCONTACTNO` varchar(30) NOT NULL,
  `COMPANYSTATUS` varchar(90) NOT NULL,
  `COMPANYMISSION` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcompany`
--

INSERT INTO `tblcompany` (`COMPANYID`, `COMPANYNAME`, `COMPANYADDRESS`, `COMPANYCONTACTNO`, `COMPANYSTATUS`, `COMPANYMISSION`) VALUES
(8, 'Myanmar Brewery Limited', 'No. 5, Pyay Road, Hlaing Township, Yangon', '09445621888', '', ''),
(9, 'KBZ Bank', 'No. 576, Merchant Street, Kyauktada Township, Yangon', '09897654777', '', ''),
(10, 'Ooredoo Myanmar', 'Ooredoo Tower, Corner of Bogyoke Aung San Road and Theinbyu Road, Yangon', '09897672222', '', ''),
(11, 'Amazing Myanmar Tours', '23/ Kantar Qrt,Corner of  Ayesein Road, Mandalay', '09 683456705', '', ''),
(12, 'Golden Land Agriculture', 'Farm 15, Agricultural Zone, Pyinmana Township , Naypyidaw Region', '09897654321', '', ''),
(13, 'Yangon International Education Center', '97/ Marhar Ayekan Road, Yangon', '09889765677', '', ''),
(14, 'Myanmar Tech Solutions', 'No. 123, Tech Hub Building, Bahan Township, Yangon', '09987654321', '', ''),
(15, 'Myanmar Construction Group', 'No.21 ,Center Road , Kamayu Township , yangon', '09897654443', '', ''),
(16, 'Myanmar Community Development', 'No.4,Community Center, Taunggyi Township, Shan State', '09897656523', '', ''),
(17, 'Myanmar HR  Group', 'No.78, Center, Mahavandoola Road, Yangon', '09 683456705', '', ''),
(18, 'Digital Myanmar Agency', 'No. 456,Digtal Plaza, Pyay Road, Sanchaung Township, Yangon', '09897656788', '', ''),
(19, 'Myanmar Industrial Engineering', 'No.8, Construction Tower, Ottara Thiri Township, Naypyidaw', '09887654544', '', ''),
(20, 'Myanmar Distribution Company', 'No. 3, Industrial Zone, Hlaing Tharyar Township, Yangon', '09897676543', '', ''),
(21, 'Shipping & Logistics', 'No.55, Port Authority Building, Botataung Township, Yangon', '09445746333', '', ''),
(22, 'Myanmar International Trading', 'No.7 ,Trade Center , Strand Road, Latha Township, Yangon', '09898789876', '', ''),
(23, 'Ministry of Education', 'Building 30, Education Campus, Zabuthiri Township, Naypyidaw', '09898767612', '', ''),
(24, 'City Mart Holding Company', 'No,7 , AyeseinThi Center Road, Yangon', '09456543211', '', ''),
(26, 'Trading Companies', 'No.3 NyaungPhyu Kan Qrt, Main Road,Taunggyi', '09787656543', '', ''),
(27, 'Hello', 'No.3 NyaungPhyu Kan Qrt, Main Road,Taunggyi', '09897654321', '', ''),
(28, 'Hello sale', 'No.123 Maharbadoola Road, Taunggyi', '09898767654', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `INCID` int(11) NOT NULL,
  `EMPLOYEEID` varchar(30) NOT NULL,
  `FNAME` varchar(50) NOT NULL,
  `LNAME` varchar(50) NOT NULL,
  `MNAME` varchar(50) NOT NULL,
  `ADDRESS` varchar(90) NOT NULL,
  `BIRTHDATE` date NOT NULL,
  `BIRTHPLACE` varchar(90) NOT NULL,
  `AGE` int(11) NOT NULL,
  `SEX` varchar(30) NOT NULL,
  `CIVILSTATUS` varchar(30) NOT NULL,
  `TELNO` varchar(40) NOT NULL,
  `EMP_EMAILADDRESS` varchar(90) NOT NULL,
  `CELLNO` varchar(30) NOT NULL,
  `POSITION` varchar(50) NOT NULL,
  `WORKSTATS` varchar(90) NOT NULL,
  `EMPPHOTO` varchar(255) NOT NULL,
  `EMPUSERNAME` varchar(90) NOT NULL,
  `EMPPASSWORD` varchar(125) NOT NULL,
  `DATEHIRED` date NOT NULL,
  `COMPANYID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`INCID`, `EMPLOYEEID`, `FNAME`, `LNAME`, `MNAME`, `ADDRESS`, `BIRTHDATE`, `BIRTHPLACE`, `AGE`, `SEX`, `CIVILSTATUS`, `TELNO`, `EMP_EMAILADDRESS`, `CELLNO`, `POSITION`, `WORKSTATS`, `EMPPHOTO`, `EMPUSERNAME`, `EMPPASSWORD`, `DATEHIRED`, `COMPANYID`) VALUES
(79, '1', 'Khin', 'Aye', 'Khin', 'Yangon', '2000-09-10', 'Yangon', 25, 'Female', 'Single', '09898787654', 'khinaye@gmail.com', '', 'manager', '', '', '1', '356a192b7913b04c54574d18c28d46e6395428ab', '2025-09-10', 10),
(82, '2', 'Mg', 'Soe', 'Aung', 'Inlay', '2001-08-26', 'Shanstate', 24, 'Female', 'Single', '09898787654', 'soe123@gmail.com', '', 'IT Support Specialist', '', '', '2', 'da4b9237bacccdf19c0760cab7aec4a8359010b0', '2025-09-11', 14);

-- --------------------------------------------------------

--
-- Table structure for table `tblfeedback`
--

CREATE TABLE `tblfeedback` (
  `FEEDBACKID` int(11) NOT NULL,
  `APPLICANTID` int(11) NOT NULL,
  `REGISTRATIONID` int(11) NOT NULL,
  `FEEDBACK` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblfeedback`
--

INSERT INTO `tblfeedback` (`FEEDBACKID`, `APPLICANTID`, `REGISTRATIONID`, `FEEDBACK`) VALUES
(2, 2025020, 7, 'Accept (wait for interview)'),
(3, 2025021, 9, 'Accept (wait for interview)'),
(4, 2025024, 11, 'Accept(wait for interview)'),
(5, 2025025, 13, 'Accept( Wait for interview)');

-- --------------------------------------------------------

--
-- Table structure for table `tbljob`
--

CREATE TABLE `tbljob` (
  `JOBID` int(11) NOT NULL,
  `COMPANYID` int(11) NOT NULL,
  `CATEGORY` varchar(250) NOT NULL,
  `OCCUPATIONTITLE` varchar(90) NOT NULL,
  `REQ_NO_EMPLOYEES` int(11) NOT NULL,
  `SALARIES` double NOT NULL,
  `DURATION_EMPLOYEMENT` varchar(90) NOT NULL,
  `QUALIFICATION_WORKEXPERIENCE` text NOT NULL,
  `JOBDESCRIPTION` text NOT NULL,
  `PREFEREDSEX` varchar(30) NOT NULL,
  `SECTOR_VACANCY` text NOT NULL,
  `JOBSTATUS` varchar(90) NOT NULL,
  `DATEPOSTED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbljob`
--

INSERT INTO `tbljob` (`JOBID`, `COMPANYID`, `CATEGORY`, `OCCUPATIONTITLE`, `REQ_NO_EMPLOYEES`, `SALARIES`, `DURATION_EMPLOYEMENT`, `QUALIFICATION_WORKEXPERIENCE`, `JOBDESCRIPTION`, `PREFEREDSEX`, `SECTOR_VACANCY`, `JOBSTATUS`, `DATEPOSTED`) VALUES
(1, 2, 'Technology', 'ISD', 6, 15000, 'jan 30', 'Two year Experience', 'We are looking for bachelor of science in information technology.\r\nasdasdasd', 'Male/Female', 'yes', 'Active', '2018-05-20 00:00:00'),
(2, 2, 'Technology', 'Accounting', 1, 15000, 'may 20', 'Two years Experience', 'We are looking for bachelor of science in Acountancy', 'Female', 'yes', '', '2018-05-20 02:33:00'),
(3, 2, 'Technology', 'Web Developer', 3, 20000, 'Permanent', '2+ years experience', 'Develop and maintain websites', 'Male/Female', 'IT Sector', '', '2025-09-09 05:06:52'),
(4, 9, 'Banking & Finance', 'Bank Teller', 5, 400000, 'Permanent', 'Bachelor\\\'s degree, good communication skills, basic computer knowledge', ' Handle customer transactions, account services, and cash management', 'Male/Female', 'Banking Services', 'Active', '2025-09-09 01:13:00'),
(5, 10, 'Telecommunications', 'Network Engineer', 3, 800000, 'Full-time', 'Bachelor in IT/Engineering, 2 years experience, networking certificationsrnrn', 'Maintain and optimize mobile network infrastructure', 'Male/Female', 'Telecommunications Infrastructure', 'Active', '2025-09-09 01:14:00'),
(6, 11, 'Hospitality & Tourism', 'English-Speaking Tour Guide', 2, 500000, 'Contract', 'Fluent English, knowledge of Myanmar culture, tourism certificaternrn', ' Guide foreign tourists to cultural sites around Myanmar', 'Male/Female', 'Tourism SServices', 'Active', '2025-09-09 01:16:00'),
(7, 12, 'Agriculture & Farming', 'Agriculture Development Specialist', 4, 600000, 'Permanebt', 'Degree in agriculture, 3 years experience, knowledge of local farming practices', 'Develop and implement improved farming techniques in rural areas', 'Male/Female', 'Agricultural Development', 'Active', '2025-09-09 01:42:00'),
(8, 13, 'Education & Teaching', 'English Teacher', 3, 450000, '1 year Contract', 'Bachelor\\\'s degree , TEFL certification, teaching experience preferred', 'Teach English to students of various age groups and levels', 'Male/Female', 'Education Services', 'Active', '2025-09-09 01:45:00'),
(9, 9, 'Banking & Finance', 'Branch Manager', 2, 500000, 'Permanent', 'Bachelor\\\'s in Finance/Business, 5+ years banking experience, leadership skills', 'Manage branch operations, staff supervision, customer service excellence, and business growth', 'Male/Female', 'Banking Operations', 'Active', '2025-09-09 02:14:00'),
(10, 9, 'Banking & Finance', 'Loan Officer', 5, 700000, 'Permanent', 'Bachelor\\\'s degree, 2+ years banking experience, good analytical skills', 'Evaluate loan applications, client interviews, risk assessment, and documentation', 'Male/Female', 'Credit Services', 'Active', '2025-09-09 02:15:00'),
(12, 10, 'Telecommunications', 'Customer Service Representative', 3, 400000, 'Permanent', ' High school diploma, good communication skills, basic computer knowledge', 'Handle customer inquiries, resolve complaints, provide product information', 'Male/Female', 'Customer Support', 'Active', '2025-09-09 02:19:00'),
(14, 11, 'Hospitality & Tourism', ' Travel Consultant', 3, 350000, 'Permanent', ' Bachelor\\\'s degree, good communication, computer skills', 'Plan travel itineraries, book accommodations, handle customer requests', 'Male/Female', 'Travel Services', 'Active', '2025-09-09 02:22:00'),
(15, 8, 'Manufacturing & Production', ' Quality Control Supervisor', 2, 800000, 'Permanent', ' Degree in Chemistry/Food Science, 3+ years QC experience', 'Monitor production quality, implement quality standards, team supervision', 'Male/Female', 'Quality Assurance', 'Active', '2025-09-09 02:24:00'),
(18, 14, 'Technology', 'Junior Software Developer', 4, 800000, 'Permanent', 'Bachelor\\\'s in Computer Science, knowledge of PHP/JavaScript, 1+ year experience', ' Develop web applications, maintain existing systems, collaborate with team', 'Male', 'Software Development', 'Active', '2025-09-09 02:47:00'),
(19, 15, 'Construction &Engineering', 'Site Civil Engineer', 3, 950000, '2-Year Project', 'Bachelor\\\'s in Civil Engineering, 3+ years experience, project management skills', ': Supervise construction sites, ensure quality standards, manage subcontractors', 'Male/Female', 'Construction Management', 'Active', '2025-09-09 02:48:00'),
(20, 16, 'NGO & Social Services', ' Community Development Officer', 2, 600000, '1-Year Contract (renewable)', 'Bachelor\\\'s in Social Work, English fluency, community engagement experience', 'Implement community projects, coordinate with local leaders, report writing', 'Male/Female', 'Community Development', 'Active', '2025-09-09 02:49:00'),
(21, 24, 'Managerial', 'Store Manager', 3, 1000000, 'Permanent', 'Bachelor\\\'s degree, 5+ years retail management, leadership skills', ' Manage store operations, staff supervision, inventory control, sales targets', 'Female', 'Retail Management', 'Active', '2025-09-09 02:51:00'),
(22, 17, 'HR', ' Recruitment Officer', 2, 700000, 'Permanent', 'Bachelor\\\'s in HR/Business, 2+ years recruitment experience, interview skills', ' Source candidates, conduct interviews, onboarding processes, HR administrationrn', 'Male/Female', 'Human Resources', 'Active', '2025-09-09 02:52:00'),
(23, 19, 'Engineering', 'Mechanical Design Engineer', 2, 900000, 'Permanent', 'Bachelor\\\'s in Mechanical Engineering, AutoCAD skills, 3+ years experience', 'Design mechanical systems, equipment maintenance planning, technical drawings', 'Male/Female', 'Industrial Engineering', 'Active', '2025-09-09 02:53:00'),
(24, 20, 'Sales', 'Senior Sales Executive', 5, 500000, 'Permanent', 'Any Bachelor\\\'s degree, 2+ years sales experience, negotiation skills', ' Client acquisition, sales targets, product demonstrations, relationship management', 'Female', 'Sales', 'Active', '2025-09-09 02:55:00'),
(25, 21, 'Shipping', ' Shipping Logistics Officer', 4, 650000, 'Permanent', ' Bachelor\\\'s in Logistics, 2+ years shipping experience, documentation skills', 'Coordinate shipments, customs documentation, client communication, tracking', 'Male', 'Logistics Management', 'Active', '2025-09-09 02:56:00'),
(26, 22, 'Import/Export Trade', 'Export Documentation Officer', 3, 700000, 'Permanent', 'Bachelor\\\'s degree, export documentation knowledge, English fluency', 'Prepare export documents, customs clearance, compliance checking', 'Male/Female', 'International Trade', 'Active', '2025-09-09 02:57:00'),
(27, 23, 'Government Jobs', 'Education Development Officer', 4, 550000, 'Permanent', ' Bachelor\\\'s in Education, 2+ years experience, government exam passed', ' Implement education programs, school monitoring, teacher training support', 'Male/Female', 'Public Education', 'Active', '2025-09-09 02:59:00'),
(28, 25, 'Managerial', 'Slales', 2, 500, 'Full-time', '2 year experience', 'Kind and hard working', 'Female', 'Manager', '', '2025-09-09 12:35:00'),
(29, 14, 'Technology', 'Full Stack Developer', 2, 1200000, 'Full-time', 'Bachelor\\\'s in Computer Science or related fieldrn3+ years experience in web developmentrnProficiency in PHP, JavaScript, HTML, CSSrnExperience with MySQL databasesrnKnowledge of React or Vue.js is a plus', 'Participate in code reviews and ensure high-quality code standards', 'Male/Female', 'Software Development', 'Active', '2025-09-10 16:36:00'),
(30, 18, 'Technology', 'Junior Data Analyst', 3, 900000, 'Full-time', 'Bachelor in IT and One year experience in Data Analyst', 'Analyze large datasets to extract valuable insights. Create reports and visualizations for business decisions. Work with different departments to understand data needs. Help improve data collection processes and quality.', 'Male/Female', 'Data Analytics', 'Active', '2025-09-10 16:38:00'),
(31, 14, 'Technology', ' IT Support Specialist', 4, 600000, 'Permanent', 'Diploma or Certificate in IT\\r\\n2+ years experience in IT support\\r\\nKnowledge of hardware and software troubleshooting\\r\\nGood communication skills in English and Myanmar\\r\\nCustomer service experience preferred', 'Provide technical support to company employees and clients. Troubleshoot hardware and software issues. Maintain computer systems and networks. Install and configure software and hardware. Provide training to users when needed', 'Male/Female', 'Technical Support', 'Active', '2025-09-10 16:41:00'),
(32, 21, 'Shipping', 'Warehouse Supervisor', 2, 600000, 'Permanent', 'Warehouse management experience, supervisory skills, inventory knowledge, safety awareness', 'Supervise warehouse staff, manage inventory, ensure safety standards, coordinate shipments, maintain warehouse organization', 'Male/Female', 'Warehouse Management', 'Active', '2025-09-10 16:55:00'),
(33, 21, 'Shipping', 'Freight Forwarder', 3, 720000, 'Permanent', 'Freight forwarding experience, negotiation skills, knowledge of shipping routes, customer service skills', 'Arrange cargo transportation, negotiate freight rates, prepare shipping documents, track shipments, handle customer queries', 'Male', 'Freight Forwarding', 'Active', '2025-09-10 16:57:00'),
(34, 21, 'Shipping', 'Logistics Coordinator', 4, 650000, 'Permanent', 'Logistics knowledge, coordination skills, communication skills, problem-solving ability', 'Coordinate shipments, track deliveries, communicate with clients, handle documentation, resolve logistics issues', 'Male', 'Logistics Coordination', 'Active', '2025-09-10 16:58:00'),
(35, 26, 'Import/Export Trade', 'Import Coordinator', 2, 680000, 'Permanent', 'Import procedures knowledge, coordination skills, problem-solving ability, customs regulation knowledge', 'Coordinate import shipments, handle import documentation, liaise with suppliers, track shipments, resolve import issues', 'Female', 'Import Coordination', 'Active', '2025-09-10 17:03:00'),
(36, 22, 'Import/Export Trade', 'Export Documentation Officer', 3, 700700, 'Permanent', 'Bachelor\\\'s degree, export documentation knowledge, English fluency, attention to detail', 'Prepare export documents, handle customs clearance, coordinate with shipping companies, ensure compliance with regulations', 'Male/Female', '', 'Active', '2025-09-10 17:07:00'),
(37, 27, 'Hospitality & Tourism', 'Tourism', 2, 700000, 'Permanent', 'BA Bechorlorrn2 year experience', 'Honest and hard woring and good communication', 'Male', 'Tourism', 'Active', '2025-09-11 00:55:00'),
(38, 9, 'Construction &Engineering', 'S', 0, 0, 'S', 'SS', 'S', 'None', 'S', 'Closed', '2025-09-11 01:36:00'),
(39, 28, 'Sales', 'administrator', 2, 400000, 'Full-time', 'two year experience with Administrator', 'good management and good response time correctly', 'Female', 'Admin', 'Active', '2025-09-11 02:49:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbljobregistration`
--

CREATE TABLE `tbljobregistration` (
  `REGISTRATIONID` int(11) NOT NULL,
  `COMPANYID` int(11) NOT NULL,
  `JOBID` int(11) NOT NULL,
  `APPLICANTID` int(11) NOT NULL,
  `APPLICANT` varchar(90) NOT NULL,
  `REGISTRATIONDATE` date NOT NULL,
  `REMARKS` varchar(255) NOT NULL DEFAULT 'Pending',
  `FILEID` varchar(30) DEFAULT NULL,
  `PENDINGAPPLICATION` tinyint(1) NOT NULL DEFAULT 1,
  `HVIEW` tinyint(1) NOT NULL DEFAULT 1,
  `DATETIMEAPPROVED` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbljobregistration`
--

INSERT INTO `tbljobregistration` (`REGISTRATIONID`, `COMPANYID`, `JOBID`, `APPLICANTID`, `APPLICANT`, `REGISTRATIONDATE`, `REMARKS`, `FILEID`, `PENDINGAPPLICATION`, `HVIEW`, `DATETIMEAPPROVED`) VALUES
(1, 2, 2, 2018013, 'Kim Domingo', '2018-05-27', 'Ive seen your work and its really interesting', '2147483647', 0, 1, '2018-05-26 16:13:01'),
(2, 2, 2, 2018015, 'Janry Tan', '2018-05-26', 'aasd', '2147483647', 0, 0, '2018-05-28 14:14:45'),
(3, 2, 2, 2025016, 'Mee Aye', '2025-09-08', 'Pending', '20256912529', 1, 1, '2025-09-08 17:57:00'),
(4, 0, 0, 2025017, 'zin moe', '2025-09-09', 'Pending', '20256912531', 1, 1, '2025-09-09 00:14:00'),
(5, 2, 1, 2025018, 'ma aye', '2025-09-09', 'Pending', '20256912532', 1, 1, '2025-09-09 00:32:00'),
(6, 2, 3, 2025019, 'Kyaw San', '2025-09-09', 'Pending', '20256912533', 1, 1, '2025-09-09 00:39:00'),
(7, 10, 5, 2025020, 'Mg Oo', '2025-09-09', 'Accept (wait for interview)', '20256912535', 0, 1, '2025-09-09 06:23:23'),
(8, 2, 3, 2025020, 'Mg Oo', '2025-09-09', 'Pending', '20256912536', 1, 1, '2025-09-09 01:54:00'),
(9, 10, 12, 2025021, 'Khin Aye', '2025-09-09', 'Accept (wait for interview)', '20256912537', 0, 0, '2025-09-09 17:07:12'),
(10, 24, 21, 2025021, 'Khin Aye', '2025-09-09', 'Pending', '20256912538', 1, 1, '2025-09-09 12:31:00'),
(11, 24, 21, 2025024, 'Nar Shi', '2025-09-11', 'Accept(wait for interview)', '20256912540', 0, 1, '2025-09-11 05:18:15'),
(12, 18, 30, 2025024, 'Nar Shi', '2025-09-11', 'Pending', '20256912541', 1, 1, '2025-09-11 00:44:00'),
(13, 14, 31, 2025025, 'Mg Soe', '2025-09-11', 'Accept( Wait for interview)', '20256912542', 0, 1, '2025-09-11 07:13:07'),
(14, 18, 30, 2025025, 'Mg Soe', '2025-09-11', 'Pending', '20256912543', 1, 1, '2025-09-11 02:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `USERID` varchar(30) NOT NULL,
  `FULLNAME` varchar(40) NOT NULL,
  `USERNAME` varchar(90) NOT NULL,
  `PASS` varchar(90) NOT NULL,
  `ROLE` varchar(30) NOT NULL,
  `PICLOCATION` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`USERID`, `FULLNAME`, `USERNAME`, `PASS`, `ROLE`, `PICLOCATION`) VALUES
('029839', 'Chaw Chaw Cho Aye', 'chaw', '9f8c25112bfd6a04292df8ffb87d1bcec02bd265', 'Administrator', 'photos/adm.jpg'),
('1', 'Khin Aye', 'Aye', '356a192b7913b04c54574d18c28d46e6395428ab', 'Employee', ''),
('2', 'Mg Soe', 'Soe', 'da4b9237bacccdf19c0760cab7aec4a8359010b0', 'Employee', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_audit_log`
--

CREATE TABLE `tbl_audit_log` (
  `AUDIT_ID` int(11) NOT NULL,
  `TABLE_NAME` varchar(100) DEFAULT NULL,
  `ACTION_TYPE` varchar(10) DEFAULT NULL,
  `RECORD_ID` int(11) DEFAULT NULL,
  `OLD_DATA` text DEFAULT NULL,
  `NEW_DATA` text DEFAULT NULL,
  `USER_NAME` varchar(100) DEFAULT NULL,
  `ACTION_DATE` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_audit_log`
--

INSERT INTO `tbl_audit_log` (`AUDIT_ID`, `TABLE_NAME`, `ACTION_TYPE`, `RECORD_ID`, `OLD_DATA`, `NEW_DATA`, `USER_NAME`, `ACTION_DATE`) VALUES
(1, 'tblapplicants', 'INSERT', 2025022, NULL, 'Name: Test User, Email: test@gmail.com', 'root@localhost', '2025-09-10 12:41:01'),
(2, 'tblapplicants', 'DELETE', 2025022, 'Deleted: Test User, Email: test@gmail.com', NULL, 'root@localhost', '2025-09-10 14:02:58'),
(3, 'tblapplicants', 'INSERT', 2025022, NULL, 'Name: Nadi Oo, Email: nadi@gmail.com', 'root@localhost', '2025-09-10 14:03:07'),
(4, 'tblapplicants', 'INSERT', 2025024, NULL, 'Name: Nar Shi, Email: shi123@gmail.com', 'root@localhost', '2025-09-10 22:41:21'),
(5, 'tblapplicants', 'UPDATE', 2025024, 'Old: Nar Shi, Email: shi123@gmail.com', 'New: Nar Shi, Email: shi123@gmail.com', 'root@localhost', '2025-09-10 22:43:23'),
(6, 'tblapplicants', 'INSERT', 2025025, NULL, 'Name: Mg Soe, Email: soe123@gmail.com', 'root@localhost', '2025-09-11 00:38:07'),
(7, 'tblapplicants', 'UPDATE', 2025025, 'Old: Mg Soe, Email: soe123@gmail.com', 'New: Mg Soe, Email: soe123@gmail.com', 'root@localhost', '2025-09-11 00:39:23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_backup_log`
--

CREATE TABLE `tbl_backup_log` (
  `backup_id` int(11) NOT NULL,
  `backup_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `table_name` varchar(100) DEFAULT NULL,
  `record_count` int(11) DEFAULT NULL,
  `backed_up_by` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_backup_log`
--

INSERT INTO `tbl_backup_log` (`backup_id`, `backup_date`, `table_name`, `record_count`, `backed_up_by`) VALUES
(1, '2025-09-10 12:39:18', 'tblapplicants', 9, 'root@localhost');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_job_archive`
--

CREATE TABLE `tbl_job_archive` (
  `archive_id` int(11) NOT NULL,
  `JOBID` int(11) DEFAULT NULL,
  `OCCUPATIONTITLE` varchar(255) DEFAULT NULL,
  `COMPANYNAME` varchar(255) DEFAULT NULL,
  `archived_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_active_jobs`
-- (See below for the actual view)
--
CREATE TABLE `vw_active_jobs` (
`JOBID` int(11)
,`COMPANYID` int(11)
,`CATEGORY` varchar(250)
,`OCCUPATIONTITLE` varchar(90)
,`REQ_NO_EMPLOYEES` int(11)
,`SALARIES` double
,`DURATION_EMPLOYEMENT` varchar(90)
,`QUALIFICATION_WORKEXPERIENCE` text
,`JOBDESCRIPTION` text
,`PREFEREDSEX` varchar(30)
,`SECTOR_VACANCY` text
,`JOBSTATUS` varchar(90)
,`DATEPOSTED` datetime
,`COMPANYNAME` varchar(90)
,`COMPANYADDRESS` varchar(90)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_applicant_details`
-- (See below for the actual view)
--
CREATE TABLE `vw_applicant_details` (
`APPLICANTID` int(11)
,`FNAME` varchar(90)
,`LNAME` varchar(90)
,`MNAME` varchar(90)
,`ADDRESS` varchar(255)
,`SEX` varchar(11)
,`CIVILSTATUS` varchar(30)
,`BIRTHDATE` date
,`BIRTHPLACE` varchar(255)
,`AGE` int(2)
,`USERNAME` varchar(90)
,`PASS` varchar(90)
,`EMAILADDRESS` varchar(90)
,`CONTACTNO` varchar(90)
,`DEGREE` text
,`APPLICANTPHOTO` varchar(255)
,`NATIONALID` varchar(255)
,`JobsApplied` bigint(21)
);

-- --------------------------------------------------------

--
-- Structure for view `vw_active_jobs`
--
DROP TABLE IF EXISTS `vw_active_jobs`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_active_jobs`  AS SELECT `j`.`JOBID` AS `JOBID`, `j`.`COMPANYID` AS `COMPANYID`, `j`.`CATEGORY` AS `CATEGORY`, `j`.`OCCUPATIONTITLE` AS `OCCUPATIONTITLE`, `j`.`REQ_NO_EMPLOYEES` AS `REQ_NO_EMPLOYEES`, `j`.`SALARIES` AS `SALARIES`, `j`.`DURATION_EMPLOYEMENT` AS `DURATION_EMPLOYEMENT`, `j`.`QUALIFICATION_WORKEXPERIENCE` AS `QUALIFICATION_WORKEXPERIENCE`, `j`.`JOBDESCRIPTION` AS `JOBDESCRIPTION`, `j`.`PREFEREDSEX` AS `PREFEREDSEX`, `j`.`SECTOR_VACANCY` AS `SECTOR_VACANCY`, `j`.`JOBSTATUS` AS `JOBSTATUS`, `j`.`DATEPOSTED` AS `DATEPOSTED`, `c`.`COMPANYNAME` AS `COMPANYNAME`, `c`.`COMPANYADDRESS` AS `COMPANYADDRESS` FROM (`tbljob` `j` join `tblcompany` `c` on(`j`.`COMPANYID` = `c`.`COMPANYID`)) WHERE `j`.`JOBSTATUS` = 'Active' ;

-- --------------------------------------------------------

--
-- Structure for view `vw_applicant_details`
--
DROP TABLE IF EXISTS `vw_applicant_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_applicant_details`  AS SELECT `a`.`APPLICANTID` AS `APPLICANTID`, `a`.`FNAME` AS `FNAME`, `a`.`LNAME` AS `LNAME`, `a`.`MNAME` AS `MNAME`, `a`.`ADDRESS` AS `ADDRESS`, `a`.`SEX` AS `SEX`, `a`.`CIVILSTATUS` AS `CIVILSTATUS`, `a`.`BIRTHDATE` AS `BIRTHDATE`, `a`.`BIRTHPLACE` AS `BIRTHPLACE`, `a`.`AGE` AS `AGE`, `a`.`USERNAME` AS `USERNAME`, `a`.`PASS` AS `PASS`, `a`.`EMAILADDRESS` AS `EMAILADDRESS`, `a`.`CONTACTNO` AS `CONTACTNO`, `a`.`DEGREE` AS `DEGREE`, `a`.`APPLICANTPHOTO` AS `APPLICANTPHOTO`, `a`.`NATIONALID` AS `NATIONALID`, count(`r`.`JOBID`) AS `JobsApplied` FROM (`tblapplicants` `a` left join `tbljobregistration` `r` on(`a`.`APPLICANTID` = `r`.`APPLICANTID`)) GROUP BY `a`.`APPLICANTID` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblapplicants`
--
ALTER TABLE `tblapplicants`
  ADD PRIMARY KEY (`APPLICANTID`);

--
-- Indexes for table `tblattachmentfile`
--
ALTER TABLE `tblattachmentfile`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  ADD PRIMARY KEY (`AUTOID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CATEGORYID`);

--
-- Indexes for table `tblcompany`
--
ALTER TABLE `tblcompany`
  ADD PRIMARY KEY (`COMPANYID`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`INCID`),
  ADD UNIQUE KEY `EMPLOYEEID` (`EMPLOYEEID`);

--
-- Indexes for table `tblfeedback`
--
ALTER TABLE `tblfeedback`
  ADD PRIMARY KEY (`FEEDBACKID`);

--
-- Indexes for table `tbljob`
--
ALTER TABLE `tbljob`
  ADD PRIMARY KEY (`JOBID`);

--
-- Indexes for table `tbljobregistration`
--
ALTER TABLE `tbljobregistration`
  ADD PRIMARY KEY (`REGISTRATIONID`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`USERID`);

--
-- Indexes for table `tbl_audit_log`
--
ALTER TABLE `tbl_audit_log`
  ADD PRIMARY KEY (`AUDIT_ID`);

--
-- Indexes for table `tbl_backup_log`
--
ALTER TABLE `tbl_backup_log`
  ADD PRIMARY KEY (`backup_id`);

--
-- Indexes for table `tbl_job_archive`
--
ALTER TABLE `tbl_job_archive`
  ADD PRIMARY KEY (`archive_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblapplicants`
--
ALTER TABLE `tblapplicants`
  MODIFY `APPLICANTID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2025026;

--
-- AUTO_INCREMENT for table `tblattachmentfile`
--
ALTER TABLE `tblattachmentfile`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  MODIFY `AUTOID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CATEGORYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tblcompany`
--
ALTER TABLE `tblcompany`
  MODIFY `COMPANYID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `INCID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `tblfeedback`
--
ALTER TABLE `tblfeedback`
  MODIFY `FEEDBACKID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbljob`
--
ALTER TABLE `tbljob`
  MODIFY `JOBID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `tbljobregistration`
--
ALTER TABLE `tbljobregistration`
  MODIFY `REGISTRATIONID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_audit_log`
--
ALTER TABLE `tbl_audit_log`
  MODIFY `AUDIT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_backup_log`
--
ALTER TABLE `tbl_backup_log`
  MODIFY `backup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_job_archive`
--
ALTER TABLE `tbl_job_archive`
  MODIFY `archive_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
