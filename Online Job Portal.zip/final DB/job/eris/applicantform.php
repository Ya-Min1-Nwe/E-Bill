<div class="form-group">
	<div class="col-md-11">
	<label class="col-md-4 control-label" for="FNAME">Firstname:</label>
		<div class="col-md-8">
		  <input name="JOBID" type="hidden" value="<?php echo isset($_GET['job']) ? $_GET['job'] : ''; ?>">
		   <input class="form-control input-sm" id="FNAME" name="FNAME" placeholder="Firstname" type="text" value="" onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off">
		</div>
	</div>
</div>

<div class="form-group">
	<div class="col-md-11">
		<label class="col-md-4 control-label" for="LNAME">Lastname:</label>
		<div class="col-md-8">
		  <input name="deptid" type="hidden" value="">
		  <input class="form-control input-sm" id="LNAME" name="LNAME" placeholder="Lastname" onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off">
		  </div>
	</div>
</div>

<div class="form-group">
	<div class="col-md-11">
		<label class="col-md-4 control-label" for="MNAME">Middle Name:</label>
		<div class="col-md-8">
		  <input name="deptid" type="hidden" value="">
		  <input class="form-control input-sm" id="MNAME" name="MNAME" placeholder="Middle Name" onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off">
		</div>
	</div>
</div> 

<div class="form-group">
	<div class="col-md-11">
		<label class="col-md-4 control-label" for="ADDRESS">Address:</label>
		<div class="col-md-8">
		 <textarea class="form-control input-sm" id="ADDRESS" name="ADDRESS" placeholder="Address" required onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off"></textarea>
		</div>
	</div>
</div> 

<div class="form-group">
	<div class="col-md-11">
		<label class="col-md-4 control-label" for="Gender">Sex:</label>
		<div class="col-md-8">
		 <div class="col-lg-5">
		    <div class="radio">
		      <label><input id="optionsRadios1" name="optionsRadios" type="radio" value="Female">Female</label>
		    </div>
		  </div>
		  <div class="col-lg-4">
		    <div class="radio">
		      <label><input id="optionsRadios2" name="optionsRadios" type="radio" value="Male"> Male</label>
		    </div>
		  </div> 
		</div>
	</div>
</div>

<div class="form-group">
  <div class="rows">
    <div class="col-md-11"> 
      <div class="col-md-4">
        <label class="col-lg-11 control-label">Date of Birth</label>
      </div>

      <div class="col-lg-3">
        <select class="form-control input-sm" name="month">
          <option value="">Month</option>
          <?php
             $mon = array('Jan' => 1 ,'Feb'=> 2,'Mar' => 3 ,'Apr'=> 4,'May' => 5 ,'Jun'=> 6,'Jul' => 7 ,'Aug'=> 8,'Sep' => 9 ,'Oct'=> 10,'Nov' => 11 ,'Dec'=> 12 );    
            foreach ($mon as $month => $value ) {
                   echo '<option value='.$value.'>'.$month.'</option>';
                } 
          ?>
        </select>
      </div>

      <div class="col-lg-2">
        <select class="form-control input-sm" name="day">
          <option value="">Day</option>
        <?php 
          $d = range(1, 31);
          foreach ($d as $day) {
            echo '<option value='.$day.'>'.$day.'</option>';
          }
        ?>
        </select>
      </div>

      <div class="col-lg-3">
        <select class="form-control input-sm" name="year">
          <option value="">Year</option>
        <?php 
          $years = range(2010, 1900);
          foreach ($years as $yr) {
            echo '<option value='.$yr.'>'.$yr.'</option>';
          }
        ?>
        </select>
      </div> 
    </div>
  </div>
</div> 

 <div class="form-group">
    <div class="col-md-11">
      <label class="col-md-4 control-label" for="BIRTHPLACE">Place of Birth:</label>
      <div class="col-md-8">
         <textarea class="form-control input-sm" id="BIRTHPLACE" name="BIRTHPLACE" placeholder="Place of Birth" required onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off"></textarea>
      </div>
    </div>
  </div> 

 <div class="form-group">
  <div class="col-md-11">
    <label class="col-md-4 control-label" for="TELNO">Contact No.:</label>
    <div class="col-md-8">
       <input class="form-control input-sm" id="TELNO" name="TELNO" placeholder="Contact No." type="text" required onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off">
    </div>
  </div>
</div> 

 <div class="form-group">
  <div class="col-md-11">
    <label class="col-md-4 control-label" for="CIVILSTATUS">Civil Status:</label>
    <div class="col-md-8">
      <select class="form-control input-sm" name="CIVILSTATUS" id="CIVILSTATUS">
          <option value="">Select</option>
          <option value="Single">Single</option>
          <option value="Married">Married</option>
          <option value="Widow">Widow</option>
      </select> 
    </div>
  </div>
</div>  

 <div class="form-group">
  <div class="col-md-11">
    <label class="col-md-4 control-label" for="EMAILADDRESS">Email Address:</label> 
    <div class="col-md-8">
       <input type="email" class="form-control input-sm" id="EMAILADDRESS" name="EMAILADDRESS" placeholder="Email Address" autocomplete="off"> 
    </div>
  </div>
</div>  
<div class="form-group">
  <div class="col-md-11">
    <label class="col-md-4 control-label" for="USERNAME">Username:</label>
    <div class="col-md-8">
      <input name="deptid" type="hidden" value="">
      <input class="form-control input-sm" id="USERNAME" name="USERNAME" placeholder="Username" onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off">
      </div>
  </div>
</div>

<div class="form-group">
  <div class="col-md-11">
    <label class="col-md-4 control-label" for="PASS">Password:</label>
    <div class="col-md-8">
      <input name="deptid" type="hidden" value="">
      <input class="form-control input-sm" id="PASS" name="PASS" placeholder="Password" type="password" onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off">
    </div>
  </div>
</div> 
<div class="form-group">
  <div class="col-md-11">
    <label class="col-md-4 control-label" for="DEGREE">Educational Attainment:</label>
    <div class="col-md-8">
      <input name="deptid" type="hidden" value="">
      <input class="form-control input-sm" id="DEGREE" name="DEGREE" placeholder="Educational Attainment" onkeyup="javascript:capitalize(this.id, this.value);" autocomplete="off">
      </div>
  </div>
</div> 
<div class="form-group">
    <div class="col-md-11">
      <label class="col-md-4 control-label" for="d"></label>  
      <div class="col-md-8">
        <label><input type="checkbox" id="agreeTerms"> By Sign up you are agree with our <a href="#">terms and condition</a></label>
     </div>
    </div>
</div>

<script>
// Clear form when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Clear all input fields
    var inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(function(input) {
        if (input.type !== 'submit' && input.type !== 'button' && input.type !== 'hidden') {
            input.value = '';
        }
    });
    
    // Uncheck radio buttons
    document.getElementById('optionsRadios1').checked = false;
    document.getElementById('optionsRadios2').checked = false;
    
    // Uncheck checkbox
    document.getElementById('agreeTerms').checked = false;
});
</script>