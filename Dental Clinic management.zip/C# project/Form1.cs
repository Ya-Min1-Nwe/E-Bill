﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace DentalSurgen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=dentaldb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindData();
        }

        
        void BindData()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=dentaldb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            SqlCommand cnn = new SqlCommand("Select * from dentaltab", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();

            da.Fill(table);
      


            if (table.Rows.Count > 0)
            {
                dataGridView1.AutoGenerateColumns = true;
                dataGridView1.DataSource = table;

            }
            else
            {
                dataGridView1.DataSource = null;
                MessageBox.Show("There is no data");
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cnn = new SqlCommand("Insert into dentaltab(ClientId,ClientName,Age,Phone,Address,Dentist,Symptom,Injury,Treatment) values(@clientId,@clientName,@Age,@Phone,@Address,@Dentist,@Symptom,@Injury,@Treatment)", con);

           
            cnn.Parameters.AddWithValue("@clientId", int.Parse(textBox1.Text));
            cnn.Parameters.AddWithValue("@clientName", (textBox2.Text));
            cnn.Parameters.AddWithValue("@Age", int.Parse(textBox3.Text));
            cnn.Parameters.AddWithValue("@Phone", (textBox4.Text));
            cnn.Parameters.AddWithValue("@Address", (textBox5.Text));
            cnn.Parameters.AddWithValue("@Dentist", (textBox6.Text));
            cnn.Parameters.AddWithValue("@Symptom", (textBox7.Text));
            cnn.Parameters.AddWithValue("@Injury", (textBox8.Text));
            cnn.Parameters.AddWithValue("@Treatment", (textBox9.Text));


         cnn.ExecuteNonQuery();
            con.Close();
            disp_data();
            BindData();

            MessageBox.Show("Insert Successfully");


        }

        public void disp_data()
        {
            con.Open();
            SqlCommand cnn = new SqlCommand("select * from dentaltab", con);
            cnn.Parameters.AddWithValue("@clientId", int.Parse(textBox1.Text));
            cnn.Parameters.AddWithValue("@clientName", (textBox2.Text));
            cnn.Parameters.AddWithValue("@Age", int.Parse(textBox3.Text));
            cnn.Parameters.AddWithValue("@Phone", (textBox4.Text));
            cnn.Parameters.AddWithValue("@Address", (textBox5.Text));
            cnn.Parameters.AddWithValue("@Dentist", (textBox6.Text));
            cnn.Parameters.AddWithValue("@Symptom", (textBox7.Text));
            cnn.Parameters.AddWithValue("@Injury", (textBox8.Text));
            cnn.Parameters.AddWithValue("@Treatment", (textBox9.Text));



            cnn.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable dt = new DataTable();
            dt.Clear();
            
            da.Fill(dt);
            
            dataGridView1.DataSource = dt;
            

            con.Close();
        }


        private void button4_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=dentaldb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            SqlCommand cnn = new SqlCommand("Update dentaltab set ClientName=@clientName ,Age=@Age,Phone=@Phone,Address=@Address,Dentist=@Dentist,Symptom=@Symptom,Injury=@Injury,Treatment=@Treatment where ClientId=@clientId", con);


            cnn.Parameters.AddWithValue("@clientId", int.Parse(textBox1.Text));
            cnn.Parameters.AddWithValue("@clientName", (textBox2.Text));
            cnn.Parameters.AddWithValue("@Age", int.Parse(textBox3.Text));
            cnn.Parameters.AddWithValue("@Phone", (textBox4.Text));
            cnn.Parameters.AddWithValue("@Address", (textBox5.Text));
            cnn.Parameters.AddWithValue("@Dentist", (textBox6.Text));
            cnn.Parameters.AddWithValue("@Symptom", (textBox7.Text));
            cnn.Parameters.AddWithValue("@Injury", (textBox8.Text));
            cnn.Parameters.AddWithValue("@Treatment", (textBox9.Text));


            cnn.ExecuteNonQuery();
            con.Close();
            disp_data();
            MessageBox.Show("Successful Update");

        }



        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=dentaldb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            con.Open();
            SqlCommand cnn = new SqlCommand("Delete dentaltab where ClientId=@clientId", con);

            cnn.Parameters.AddWithValue("@clientId", int.Parse(textBox1.Text));

            
            cnn.ExecuteNonQuery();
            con.Close();
            disp_data();

            MessageBox.Show("Data deleted");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
