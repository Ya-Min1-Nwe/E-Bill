﻿CREATE TABLE [dbo].[dentaltab]
(
	[ClientId] INT NOT NULL PRIMARY KEY, 
    [ClientName] NCHAR(30) NULL, 
    [Age] INT NULL, 
    [Phone] NCHAR(15) NULL, 
    [Status] NCHAR(20) NULL, 
    [Dentist] NCHAR(20) NULL, 
    [Symptom] NCHAR(20) NULL, 
    [Injury] NCHAR(20) NULL, 
    [Treatment] NCHAR(50) NULL
)
